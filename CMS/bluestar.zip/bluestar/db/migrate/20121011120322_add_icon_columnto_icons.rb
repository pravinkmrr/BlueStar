class AddIconColumntoIcons < ActiveRecord::Migration
  def up
  end

  def down
  end
end
