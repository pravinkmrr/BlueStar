require 'test_helper'

class KeynoteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
