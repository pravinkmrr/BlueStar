require 'test_helper'

class IconsHelperTest < ActionView::TestCase
end
