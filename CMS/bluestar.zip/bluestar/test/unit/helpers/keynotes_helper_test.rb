require 'test_helper'

class KeynotesHelperTest < ActionView::TestCase
end
