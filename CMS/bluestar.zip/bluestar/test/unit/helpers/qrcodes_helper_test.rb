require 'test_helper'

class QrcodesHelperTest < ActionView::TestCase
end
