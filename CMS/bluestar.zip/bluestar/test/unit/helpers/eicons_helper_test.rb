require 'test_helper'

class EiconsHelperTest < ActionView::TestCase
end
