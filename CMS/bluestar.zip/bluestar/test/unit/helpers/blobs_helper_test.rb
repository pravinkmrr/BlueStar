require 'test_helper'

class BlobsHelperTest < ActionView::TestCase
end
