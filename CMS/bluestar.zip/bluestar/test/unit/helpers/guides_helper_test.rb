require 'test_helper'

class GuidesHelperTest < ActionView::TestCase
end
