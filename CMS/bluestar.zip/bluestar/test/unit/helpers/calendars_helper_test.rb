require 'test_helper'

class CalendarsHelperTest < ActionView::TestCase
end
