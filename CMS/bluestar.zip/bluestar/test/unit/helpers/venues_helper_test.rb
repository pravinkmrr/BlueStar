require 'test_helper'

class VenuesHelperTest < ActionView::TestCase
end
