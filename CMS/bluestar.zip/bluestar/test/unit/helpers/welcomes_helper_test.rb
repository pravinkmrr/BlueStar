require 'test_helper'

class WelcomesHelperTest < ActionView::TestCase
end
