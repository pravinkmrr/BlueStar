require 'test_helper'

class ExhibitorsHelperTest < ActionView::TestCase
end
