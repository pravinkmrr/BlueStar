require 'test_helper'

class WorkshopsHelperTest < ActionView::TestCase
end
