require 'test_helper'

class CalendersHelperTest < ActionView::TestCase
end
