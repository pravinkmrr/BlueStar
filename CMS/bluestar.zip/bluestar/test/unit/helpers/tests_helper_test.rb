require 'test_helper'

class TestsHelperTest < ActionView::TestCase
end
