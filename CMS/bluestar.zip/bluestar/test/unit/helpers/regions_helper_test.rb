require 'test_helper'

class RegionsHelperTest < ActionView::TestCase
end
