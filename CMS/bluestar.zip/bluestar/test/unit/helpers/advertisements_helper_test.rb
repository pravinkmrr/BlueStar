require 'test_helper'

class AdvertisementsHelperTest < ActionView::TestCase
end
