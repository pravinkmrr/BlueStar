require 'test_helper'

class ExhibitorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
