require 'test_helper'

class BlobTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
