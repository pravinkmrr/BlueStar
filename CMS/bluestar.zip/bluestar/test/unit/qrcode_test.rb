require 'test_helper'

class QrcodeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
