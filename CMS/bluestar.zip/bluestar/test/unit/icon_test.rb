require 'test_helper'

class IconTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
