module KeynotesHelper
end
