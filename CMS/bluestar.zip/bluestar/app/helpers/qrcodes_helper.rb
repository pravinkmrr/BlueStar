module QrcodesHelper
end
