module WelcomesHelper
end
