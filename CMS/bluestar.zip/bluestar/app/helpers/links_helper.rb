module LinksHelper
end
