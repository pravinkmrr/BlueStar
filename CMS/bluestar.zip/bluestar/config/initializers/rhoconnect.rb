Rhoconnect.configure do |config|
 
  # config.uri          = "http://localhost:9292"
  # config.token        = "e9608a9850504cef89a07a53516fd020"
  # config.app_endpoint = "http://localhost:3000"

end