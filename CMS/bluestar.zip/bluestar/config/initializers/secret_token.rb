# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Bluestar::Application.config.secret_token = '5dbe8ff1e9c9a4584697a8dd2ed433635fd2457a6b095332e52a85ae81a87665105d06c1e2be4b64dd3bce04f8aa0262bd9f2b2fec147675cb4f3b54760d1f0e'
